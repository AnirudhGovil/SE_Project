from dataclasses import dataclass

@dataclass
class CourseStudentDTO:
    course_id: int
    student_id: int